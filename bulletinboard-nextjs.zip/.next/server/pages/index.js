"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/index";
exports.ids = ["pages/index"];
exports.modules = {

/***/ "./pages/index.tsx":
/*!*************************!*\
  !*** ./pages/index.tsx ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   \"getServerSideProps\": () => (/* binding */ getServerSideProps)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next-auth/react */ \"next-auth/react\");\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction Home(props) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}, void 0, false);\n}\nconst getServerSideProps = async (ctx)=>{\n    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_2__.getSession)(ctx);\n    if (!session) {\n        return {\n            redirect: {\n                permanent: false,\n                destination: \"/login\"\n            }\n        };\n    } else return {\n        redirect: {\n            permanent: false,\n            destination: \"/post\"\n        }\n    };\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBQTtBQUEwQjtBQUNtQjtBQUU3QyxTQUFTRSxJQUFJLENBQUNDLEtBQVUsRUFBRTtJQUN4QixxQkFDRSw2SUFDRyxDQUNKO0NBQ0Y7QUFFTSxNQUFNQyxrQkFBa0IsR0FBRyxPQUFPQyxHQUFHLEdBQUs7SUFDL0MsTUFBTUMsT0FBTyxHQUFRLE1BQU1MLDJEQUFVLENBQUNJLEdBQUcsQ0FBQztJQUMxQyxJQUFJLENBQUNDLE9BQU8sRUFBRTtRQUNWLE9BQU87WUFDSEMsUUFBUSxFQUFFO2dCQUNOQyxTQUFTLEVBQUUsS0FBSztnQkFDaEJDLFdBQVcsRUFBRSxRQUFRO2FBQ3hCO1NBQ0o7S0FDSixNQUFNLE9BQU87UUFDWkYsUUFBUSxFQUFFO1lBQ1JDLFNBQVMsRUFBRSxLQUFLO1lBQ2hCQyxXQUFXLEVBQUUsT0FBTztTQUN2QjtLQUNBO0NBQ0Y7QUFFRCxpRUFBZVAsSUFBSSIsInNvdXJjZXMiOlsid2VicGFjazovL2J1bGxldGluYm9hcmQtbmV4dGpzLy4vcGFnZXMvaW5kZXgudHN4PzA3ZmYiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgZ2V0U2Vzc2lvbiB9IGZyb20gXCJuZXh0LWF1dGgvcmVhY3RcIjtcblxuZnVuY3Rpb24gSG9tZShwcm9wczogYW55KSB7XG4gIHJldHVybiAoXG4gICAgPD5cbiAgICA8Lz5cbiAgKVxufVxuXG5leHBvcnQgY29uc3QgZ2V0U2VydmVyU2lkZVByb3BzID0gYXN5bmMgKGN0eCkgPT4ge1xuICBjb25zdCBzZXNzaW9uOiBhbnkgPSBhd2FpdCBnZXRTZXNzaW9uKGN0eClcbiAgaWYgKCFzZXNzaW9uKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICAgIHJlZGlyZWN0OiB7XG4gICAgICAgICAgICAgIHBlcm1hbmVudDogZmFsc2UsXG4gICAgICAgICAgICAgIGRlc3RpbmF0aW9uOiAnL2xvZ2luJ1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgfSBlbHNlIHJldHVybiB7XG4gICAgcmVkaXJlY3Q6IHtcbiAgICAgIHBlcm1hbmVudDogZmFsc2UsXG4gICAgICBkZXN0aW5hdGlvbjogJy9wb3N0J1xuICB9XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgSG9tZSJdLCJuYW1lcyI6WyJSZWFjdCIsImdldFNlc3Npb24iLCJIb21lIiwicHJvcHMiLCJnZXRTZXJ2ZXJTaWRlUHJvcHMiLCJjdHgiLCJzZXNzaW9uIiwicmVkaXJlY3QiLCJwZXJtYW5lbnQiLCJkZXN0aW5hdGlvbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/index.tsx\n");

/***/ }),

/***/ "next-auth/react":
/*!**********************************!*\
  !*** external "next-auth/react" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/index.tsx"));
module.exports = __webpack_exports__;

})();